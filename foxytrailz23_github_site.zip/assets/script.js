
// Minimal JS for menu / tracking stubs
(function(){
  // Google Tag Manager stub: replace with your live container if not already injected inline.
  console.log('Foxytrailz23 site ready.');
})();
