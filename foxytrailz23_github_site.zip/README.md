
# Foxytrailz23 — GitHub Pages Starter (MVP)

This is a drop-in, working starter for your GitHub Pages site. It mirrors your style: fast hub, no‑nonsense, with **AI Tools** and **AI Games** pages.

## What’s inside
- `index.html` — Home with Start the Show + Shop + sticker placeholder
- `ai.html` — Buttons to Kaiber, Pika, Adobe Enhance, remove.bg
- `games.html` — Browser Tic‑Tac‑Toe and Emoji Guess
- `assets/style.css` — Dark, clean theme
- `assets/script.js` — Minimal JS
- **GTM** already included: `GTM-P4WXVWV7`
- Amazon affiliate example: `?tag=a2q8lf6frm9nm-20`
- Footer + watermark: `www.foxytrailz23.com`

## Deploy on GitHub Pages (5 steps)
1. Create a new repo named **foxytrailz23-website** on GitHub (Public).
2. Upload all files in this folder (or drag & drop in the GitHub web UI).
3. In the repo: **Settings → Pages → Build and deployment → Source = Deploy from branch → Branch = `main` → `/ (root)`**. Save.
4. Wait for the green check. Your site will be live at `https://<your-username>.github.io/foxytrailz23-website/`.
5. Optional: set a custom domain in **Settings → Pages → Custom domain** (CNAME will be created).

## Customize
- Replace `assets/foxy-sticker-placeholder.png` with your real sticker (same file name).
- Update outbound links to pass through GTM / your link shortener for tracking.
- Add more tools/games: duplicate the cards/sections.

## Notes
- No real face is used anywhere.
- Keep everything fast and simple. Add heavier AI later (webLLM/HF Spaces) when we confirm providers that allow embeds.
